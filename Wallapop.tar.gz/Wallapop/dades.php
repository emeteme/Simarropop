<?php
$host = "localhost";
$user = "root";
$pass = "";
$bd = "consum";
$port = "3306";
?>
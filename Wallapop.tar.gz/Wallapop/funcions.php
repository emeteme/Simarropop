<?php
include ("dades.php");

//Conexio amb la base de dades
function conectarbda($host, $user, $pass, $bd, $port)
{
    $conexio = mysqli_connect($host, $user, $pass, $bd, $port);
    if ($conexio) {
        return $conexio;
    } else {
        return false;
    }
}

//InsertarProducte
function insertarproducto($conexio, $producto, $precio, $destacado, $stock)
{
    $consulta = "INSERT INTO productos (producto,precio,destacado,stock) VALUES ('$producto', $precio,$destacado,$stock)";
    $resultado = mysqli_query($conexio, $consulta);

}

?>
<?php

include ("dades.php");
include ("funcions.php");
if ($conexio = conectarbda($host, $user, $pass, $bd, $port)) {
    print "Conexio correcta";
    $producto = $_POST["producto"];
    $precio = $_POST["precio"];
    $destacado = $_POST["destacado"];
    $stock = $_POST["stock"];
    insertarproducto($conexio, $producto, $precio, $destacado, $stock);
}

?>